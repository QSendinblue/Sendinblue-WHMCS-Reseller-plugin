<?php
class sibecp_config {
	public $SMTPpassword = '';
	public $cpanelPluginAccessToken = '3Lop8D8JX5UCfwnu092dHdu1TcaIq7Dv65NIxAUw7X6f1eMGjVgSOleuEIylSTQPEOvkk6ll6IVbl1UQhjNSaLepw9V1jl5sMMOMW1Jy7EgrLn4ouSqcVPcfweXNC2gL';
}
