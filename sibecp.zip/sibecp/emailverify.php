<?php
// load WHMCS
require_once '../../../init.php';
require_once 'sibecp.php';
use WHMCS\Database\Capsule;
use WHMCS\Config\Setting;

define('sFUNCTION', 'sibecp_emailverify');

$vs = $_REQUEST['vs'];
$hash = urldecode($vs);
//according to documentation Capsule escepe all input but to be sure hash will be checked up
$AllowedChars = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
for ($ii = 0; $ii < strlen($vs); $ii++ ) {
	$chk = substr($vs, $ii, 1);
	if (strpos($AllowedChars, $chk) === false) { $errorMsg = 'The verification link is invalid.'; }
}

if (!isset($errorMsg)) {

	$rows = Capsule::table('tblcustomfieldsvalues')->where('value', 'like', '%' . $hash . '%')->get();
	
	if (count($rows) != 1) { // =0 - not found, =2 data is irregular, should be checked by admin - both cases stops the procedure 
		$errorMsg = 'The verification link is invalid - it is wrong or it is expired.';
	} else {
		$CustomFieldId = 0;
		$row = $rows[0];
		$dataJSON = htmlspecialchars_decode($row->value);
		$dataOld = json_decode($dataJSON);
	
		foreach ($dataOld as $item) {
			if($item->hash == $hash) {
				$diff = time() - strtotime($item->submitted);
				if ($diff > (24 * 60 * 60)) {
					$errorMsg = "The verification link is expired.";
					break;
				} else {
					$AddSenderDomain = $item->domain;
					$item->verified = date('Y-m-d H:i:s', time());
					$item->hash = '';
					$CustomFieldId = $row->id;
					$serviceid = $row->relid;
				}	
			}
			$data[] = $item;		
		} 
		if ($CustomFieldId == 0) {
			if (!isset($errorMsg)) { $errorMsg = 'The verification link data not found.'; }		
		} else {
			$apiKeyFieldId = 0;
			$rows = Capsule::table('tblcustomfieldsvalues')->where('relid', $serviceid)->get();
			if (count($rows) == 0) {
				$errorMsg = 'Unable to load data';
			} else {
				foreach ($rows as $row) {
					$rows_fields = Capsule::table('tblcustomfields')->where('id', $row->fieldid)->get();
					if (count($rows_fields) != 0) {
						if($rows_fields[0]->type == 'product' && $rows_fields[0]->fieldname == FIELDNAME_APIKEY) {
							$apiKeyFieldId = $rows_fields[0]->id;
							break;
						}
					}
				}
				if($apiKeyFieldId == 0) {
					$errorMsg = 'Unable to load client data';
				} else {
					$rows = Capsule::table('tblcustomfieldsvalues')->where('relid', $serviceid)->where('fieldid', $apiKeyFieldId)->get();
					if (count($rows) == 0) {
						$errorMsg = 'Unable to load client api-key data';
					} else {
						$childAuthKey = $rows[0]->value;
						$rows = Capsule::table('tblhosting')->where('id', $serviceid)->get();
						if (count($rows) == 0) {
							$errorMsg = 'Unable to load service data';
						} else {
							$serverId = $rows[0]->server;
							$rows = Capsule::table('tblservers')->where('id', $serverId)->get();
							if (count($rows) == 0) {
								$errorMsg = 'Unable to load server data';
							} else {
								$serverAuthKey = $rows[0]->accesshash;
								try {
									$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $serverAuthKey);
									$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
									$ChildDomains = $ResellerApiInstance->getChildDomainsB($childAuthKey);
									foreach ($ChildDomains as $item) {
										if ($item->domain == $AddSenderDomain && $item->active == true) { $domainExist = true; } 
									}
						        } catch (Exception $e) {
						        	$logMsg = 'Error: Unable to load data from Sendinblue server for subaccount with api-key "' . $childAuthKey . '". Error: ' . $e->getMessage();
									logModuleCall( MODULE_NAME, sFUNCTION, $params, $logMsg, '' );
									$errorMsg = 'Unable to load data from server.';
						        }
								if (isset($domainExist)) {
									$message = 'Sender domain "' . $AddSenderDomain . '" is already added to your account.';
								} else {
									try {	
										$addChildDomain = new \SendinBlue\Client\Model\AddChildDomain(array('domain' => trim($AddSenderDomain))); // \SendinBlue\Client\Model\AddChildDomain | Sender domain to add for a specific child account	
									    $ResellerApiInstance->createChildDomain($childAuthKey, $addChildDomain);
										// after succesfull add update data in WHMVS
										$value = json_encode($data);
										if(!($updated_customfield = Capsule::table('tblcustomfieldsvalues')->where('id', $CustomFieldId)->update(array('value' => $value, 'updated_at' => Capsule::raw('NOW()'))))) {
											$logMsg = 'Error: Unable to update custom field "' . $field_title_const . '" data row.';
											logModuleCall( MODULE_NAME, sFUNCTION, $params, $logMsg, '' );
											$errorMsg = "Unable to update data."; 
										} else {
											$message = 'Sender domain "' . $AddSenderDomain . '" is successfully added to your account.';
										}
							        } catch (Exception $e) {
							        	$logMsg = 'Error: Unable to add sender domain "' . $AddSenderDomain . '" to subaccount with api-key "' . $childAuthKey . '". Error: ' . $e->getMessage();
										logModuleCall( MODULE_NAME, sFUNCTION, $params, $logMsg, '' );
										$errorMsg = "Unable to add sender domain.";
							        }
								}
							}
						}	
					}
				}
			}
		}
	}

}
?>
<html>
	<head></head>
	<body>
		<h2><?php echo Setting::getValue('CompanyName'); ?></h2>
		<h3>Sender domain setup</h3>
		
		<?php if (isset($errorMsg)) { ?>
			<p>Error in setting up sender domain:</p>
			<p style="color: #880000;"><?php echo $errorMsg; ?></p>
			<p><?php // echo CLIENT_ERROR_MSG_CONTACT_SUPPORT; ?></p>
		<?php } ?>
		
		<?php if (isset($message)) { ?>
			<p style="color: #008800;"><?php echo $message; ?></p>
			<p>&nbsp;</p>
			<p>Visit your Manage product page at: <a href="<?php echo Setting::getValue('SystemURL'); ?>/clientarea.php?action=productdetails&id=<?php echo $serviceid; ?>">Manage product</a></p>
		<?php } ?>
	</body>
</html>












