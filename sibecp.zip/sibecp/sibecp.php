<?php
/**
 * Sendinblue Email credits packages provisioning module for WHMCS
 *
 * Basic rules:
 * 
 * - email registered for subaccount is unique id at Sendinblue server within one reseller api-key
 * - so, in order that client have unique email at sib server within reseller api-key client for  
 * 		the email which will be used for subaccount at sib server wil be in format:
 *			[useremail_leftof@]+whmcsserviceid_[serviceid]@[useremail_rightof@], 
 * 		!!! in order for subaccount to be unique quantity will be ignored (if client order 5 only one subaccount will be created) 
 * 		so, "Allow Multiple Quantities" must be OFF for all product of this type (if not hosting company will have to make partial refunds)   		 
 * - therefore in order to get subaccount it should be found by serviceid which is encoded in Sib subaccount email address
 * 		but as there is no API fn to load subbacount by email address in order to get subaccount by serviceid 
 * 		it is neccessary to load all reseller subaccounts and look through them,
 * 		so, for less responsible functions it could be used stored api-kay in whmcs table as "backlink" to subaccount:
 * 		> responsible fn: $childAuthKey = sibecp_getChildAuthKey($params);
 * 		> not responsible fn: $childAuthKey = sibecp_getCustomFeildValue($params, FIELDNAME_APIKEY);  
 * 
 * @author Branislav Gligorov <branislav.gligorov@gmail.com>
 * @copyright Sendinblue
 * @license commmercial
 * @version 2.0.0
 */

if (!defined("WHMCS")) { die("This file cannot be accessed directly"); }

// GLOBAL
define('MODULE_NAME', 'sibecp');
// custom fields names mapping ('name used in code', 'name used in product config')
define('FIELDNAME_SENDERDOMAIN', 'Sender domain');
define('FIELDNAME_APIKEY', 'Sendinblue api-key-v3');
define('FIELDNAME_CREDITS_ON_SUSPENSION', 'Credits on suspension');
define('FIELDNAME_SENDER_DOMAINS', 'Sender domains');
define('FIELDNAME_EMAIL_VERIFICATION_HASH', 'Email verification hash');
define('FIELDNAME_ADMIN_MESSAGES', 'Admin messages');

// IP pools mapping ('name used in code', 'name used in server config')
define('IP_POOL_ENTRY', 'entry');
define('IP_POOL_BAD', 'bad');
define('IP_POOL_OKAY', 'okay');
define('IP_POOL_GOOD', 'good');
define('IP_POOL_SPECIAL', 'special');

// messages
define('ERROR_MSG_UNABLE_TO_LOAD_SUBACCOUNT', 'Error: Unable to load data, please try again.');
define('CLIENT_ERROR_MSG_RETRY', 'Error: Please try again.');
define('CLIENT_ERROR_MSG_CONTACT_SUPPORT', 'Error: Please contact support.');


// config
require_once __DIR__ . '/config.php';
// additional packages added with composer (SendinBlue API, PHPmailer...)
require_once __DIR__ . '/vendor/autoload.php';
// Also, perform any initialization required by the service's library.
require_once __DIR__ . '/lib/apipatch.php';


// local classes 
use WHMCS\Database\Capsule;
use WHMCS\Service\Service;
use WHMCS\Config\Setting;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

/**
 * Special fn to create unique email address for Sendinblue server from client email and serviceid (tblhosting->id)
 * 
 * @return string on success, false on error
 */
function sibecp_getSibSubAccEmail($email, $serviceid) {
	if(!filter_var($email, FILTER_VALIDATE_EMAIL)) { throw new Exception("Error: Client email is invalid."); }
	$email_parts = explode('@', $email);
	// old idea: $SubaccountEmail = $params['userid'].'_'.$params['serviceid'].'_'.$params['pid'].'@'.$params['serverhostname'];
	$new_email = $email_parts[0] . '+whmcsserviceid_' . $serviceid . '@' . $email_parts[1];
	return $new_email;
}
/**
 * @return server IP config data
 */
function sibecp_getServerIPs($serverid) {
	$server = Capsule::table('tblservers')->where('id',$serverid)->get(); 
	$assignedips = $server[0]->assignedips;
	$serverIPs = array();
	$lines = explode(';', $assignedips);
	foreach ($lines as $line) {
		$nameparts = explode(':', $line);
		if (count($nameparts) > 1) {
			$name = trim($nameparts[0]);
			switch ($name) {
				case IP_POOL_ENTRY:
				case IP_POOL_BAD:
				case IP_POOL_OKAY:
				case IP_POOL_GOOD:
				case IP_POOL_SPECIAL:
					$name_in_arr = $name;					
					break;
				default:
					$name_in_arr = '';
					break;
			}
			$IPs = explode(',', trim($nameparts[1]));
			foreach ($IPs as $IP) {
				$IP = trim($IP);
				$validIP = filter_var($IP, FILTER_VALIDATE_IP);
				if ($validIP) { $serverIPs[$name_in_arr][] = $validIP; }
			}
		}
	}
	return $serverIPs; 
}

/**
 * @return IP from selected pool with the minimum number of subaccounts 
 */
function sibecp_getNextIP($apikey, $serverid, $pool = IP_POOL_ENTRY) {
	$serverIPs = sibecp_getServerIPs($serverid);
	if (count($serverIPs)) {
		if (isset($serverIPs[$pool])) {
			if (count($serverIPs[$pool]) > 1) {
				$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $apikey);
				$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
				$Children = $ResellerApiInstance->getResellerChilds()->getChildren();    
				foreach ($serverIPs[$pool] as $IP) { $IPcount[$IP] = 0; } // set for start 
				foreach ($Children as $item) { 
					foreach ($serverIPs[$pool] as $IP) {
						if (in_array($IP, $item['ips'])) { $IPcount[$IP]++; }
					} 
				}
				$min = array_keys($IPcount, min($IPcount));
				return $min[0];				
			} else {
				return $serverIPs[$pool][0];
			}
		}
	} else {
		return null;
	}
}

/**
 * Custom fields fns 
 * Note: Custom field data row is always created if not found
 */
function sibecp_getCustomField_FieldId($productid, $field_title_const) {
	$customfield = Capsule::table('tblcustomfields')->where('fieldname', $field_title_const)->where('type', 'product')->where('relid', $productid)->get();
	if (count($customfield)) {
		$id = $customfield[0]->id;
		return $id;
	} else {
		$logMsg = 'Error: Unable to find "' . $field_title_const . '" field id. Check product setup to have all neccessary fields properly set.';
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $logMsg, '' ); // Record the error in WHMCS's module log.
		// this shold not stop execution
		// throw new Exception(CLIENT_ERROR_MSG_CONTACT_SUPPORT);
		return 0; 
	} 
}
function sibecp_getCustomFieldId(array $params, $field_title_const) {
	$CustomField_FieldId = sibecp_getCustomField_FieldId($params['packageid'], $field_title_const);
	$customfield_row = Capsule::table('tblcustomfieldsvalues')->where('fieldid', $CustomField_FieldId)->where('relid', $params['serviceid'])->get();
	if (count($customfield_row) == 0) { // it is normall that data row does not exist if order is created through frontend 
		$customfield_id = Capsule::table('tblcustomfieldsvalues')->insertGetId(
            [
                'fieldid' => $CustomField_FieldId,
                'relid' => $params['serviceid'],
                'value' => '',
                'created_at' => Capsule::raw('NOW()')
            ]
        );
		if ( !( ((int) $customfield_id) > 0) ) {
			$logMsg = 'Error: Unable to create new custom field "' . $field_title_const . '" data row.';
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $logMsg, '' ); 
			throw new Exception(CLIENT_ERROR_MSG_CONTACT_SUPPORT);
		}
	} else { 
		$customfield_id = (int) $customfield_row[0]->id;
	} 
	return $customfield_id;
}
// return plain stored value - not formated
function sibecp_getCustomFeildValue($params, $field_title_const) {
	$CustomFieldId = sibecp_getCustomFieldId($params, $field_title_const);
	$customfield_row = Capsule::table('tblcustomfieldsvalues')->where('id', $CustomFieldId)->get();
	return $customfield_row[0]->value; 
}
function sibecp_setCustomFeildValue($params, $field_title_const, $value) {
	$CustomFieldId = sibecp_getCustomFieldId($params, $field_title_const);
	if(!($updated_customfield = Capsule::table('tblcustomfieldsvalues')->where('id', $CustomFieldId)->update(array('value' => $value, 'updated_at' => Capsule::raw('NOW()'))))) {
		$logMsg = 'Error: Unable to update custom field "' . $field_title_const . '"data row.';
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $logMsg, '' ); 
		throw new Exception(CLIENT_ERROR_MSG_CONTACT_SUPPORT);
	}
	return $updated_customfield;
}


/**
 * @return null or subaccount object from Sendinblue found by serviceid stored in email address at Sendinblue
 */
function sibecp_getSubaccountFromSendinblueByServiceId($params) {
	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
	$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
	$ResellerChilds = $ResellerApiInstance->getResellerChilds();
	$Children = $ResellerChilds->getChildren();    
	$foundChild = null;
	foreach ($Children as $item) {
		$mailparts = explode('@', $item['email']);
		$mailnameparts = explode('+', $mailparts[0]);
		$whmcsparts = explode('_', $mailnameparts[1]);
		if ($whmcsparts[0] == 'whmcsserviceid' && (int) $whmcsparts[1] == $params['serviceid']) { $foundChild = $item; break; }
	}
	// if ($foundChild != null) { $childAuthKey = $foundChild['apiKeys']->v3[0]->key; }
	return $foundChild;
}
/**
 * @return false or array of \SendinBlue\Client\Model\GetChildInfo, HTTP status code, HTTP response headers (array of strings)
 * 				by apykey stored in product (with check if serviceid matches email address in Sendinblue)
 */
function sibecp_getSubaccount($params, $throwEx = false) {
	$err_msgs = array();
	// try to load data first with loacaly set api-key (loading only one account from Sendinblue)
	$childAuthKey = sibecp_getCustomFeildValue($params, FIELDNAME_APIKEY);
	if (trim($childAuthKey) == '') {
		// fallback to look by serviceid
		$foundChild = sibecp_getSubaccountFromSendinblueByServiceId($params); // looking in all accounts from Sendinblue
		if ($foundChild === null) {
			$err_msgs[] = 'Error: Subaccount not found on server by serviceid or by api-key.';
			if ($throwEx) { throw new Exception ($err_msgs[count($err_msgs)-1]); }
		} else {
			// in this case custom field could be reasigned automaticcaly to correct value but it will not be done as it should be found why there is this wrong data  
			$err_msgs[] = 'Error: Subaccount found on server by serviceid but api-key in WHMCS is empty. Check the data in custom field api-key for selected service, save and run Renew again. Found api-key: ' . $foundChild['apiKeys']->v3[0]->key;
			if ($throwEx) { throw new Exception ($err_msgs[count($err_msgs)-1]); }
		}
	} else {
		try { 
			$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
			$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
		    $getChildInfo = $ResellerApiInstance->getChildInfo($childAuthKey);
		} catch (SendinBlue\Client\ApiException $e) { // if there is 404 error because api-key is maybe edited in WHMCS and set to wrong value so data culd not be fond => try to find account on Sendinblue with service ID stored in email address on Sendinblue
			switch ($e->getCode()) {
				case '404':
					$foundChild = sibecp_getSubaccountFromSendinblueByServiceId($params); // looking in all accounts from Sendinblue
					if ($foundChild === null) {
						$err_msgs[] = 'Error: Subaccount not found on server by serviceid or by api-key.';
						if ($throwEx) { throw new Exception ($err_msgs[count($err_msgs)-1]); }
					} else {
						// in this case custom field could be reasigned automaticcaly to correct value but it will not be done as it should be found why there is this wrong data  
						$err_msgs[] = 'Error: Subaccount found on server by serviceid but with different api-key. Check the data in custom field api-key for selected service. Found api-key: ' . $foundChild['apiKeys']->v3[0]->key;
						if ($throwEx) { throw new Exception ($err_msgs[count($err_msgs)-1]); }
					}
					break;
				default:
					$err_msgs[] = 'Error in getting subaccount info: ' . $e->getMessage();
					if ($throwEx) { throw new Exception ($err_msgs[count($err_msgs)-1]); }	
					break;
			}
		}
	}

	if (count($err_msgs) == 0 ) { // there is some $getChildInfo 
		// it must be checked that email on sendinblue account for selected service contains the same serviceid
		$email = $getChildInfo->getEmail();
		$mailparts = explode('@', $email);
		$mailnameparts = explode('+', $mailparts[0]);
		$whmcsparts = explode('_', $mailnameparts[1]);
		if ( !($whmcsparts[0] == 'whmcsserviceid' && (int) $whmcsparts[1] == $params['serviceid']) ) {
			$err_msgs[] = 'Error: Account email on server does not match with stored api-key. Check service manualy.';
			if ($throwEx) { throw new Exception ($err_msgs[count($err_msgs)-1]); }
		}
	}

	if (count($err_msgs) != 0 ) {
		$getChildInfo = null;
		$admin_msg = sibecp_getCustomFeildValue($params, FIELDNAME_ADMIN_MESSAGES) . PHP_EOL . implode(PHP_EOL, $err_msgs);
		$updated_customfield = sibecp_setCustomFeildValue($params, FIELDNAME_ADMIN_MESSAGES, $admin_msg);
	}
	return $getChildInfo;
}
function sibecp_getChildAuthKey($params) {
	if ($ChildInfo = sibecp_getSubaccount($params)) { $childAuthKey = $ChildInfo->getApiKeys()->getV3()[0]->getKey(); }
	return $childAuthKey;
}


function sibecp_updateSmtpStatus($params, $status) {
	$ChildInfo = sibecp_getSubaccount($params); // $getSubaccount => getChildInfo
	$childAuthKey = $ChildInfo->getApiKeys()->getV3()[0]->getKey();
	// proceed with status change
	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
	$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
	$updateChildAccountStatus = new \SendinBlue\Client\Model\UpdateChildAccountStatus(array('transactionalEmail' => $status)); // \SendinBlue\Client\Model\UpdateChildAccountStatus | values to update in child account status
	$ResellerApiInstance->updateChildAccountStatus($childAuthKey, $updateChildAccountStatus);
}


/**
 * Define module related meta data.
 * Values returned here are used to determine module related abilities and settings.
 * @see https://developers.whmcs.com/provisioning-modules/meta-data-params/
 * @return array
 */
function sibecp_MetaData() {
    return array(
        'DisplayName' => 'Sendinblue Email Credits',
        'APIVersion' => '1.1', // Use API Version 1.1
        'RequiresServer' => true, // Set true if module requires a server to work
        'DefaultNonSSLPort' => '1111', // Default Non-SSL Connection Port
        'DefaultSSLPort' => '1112', // Default SSL Connection Port
        'ServiceSingleSignOnLabel' => 'Login to Panel as User',
        'AdminSingleSignOnLabel' => 'Login to Panel as Admin',
    );
}

/**
 * Define product configuration options.
 *
 * @return array
 */
function sibecp_ConfigOptions()
{
    return array(
        'Number of email credits' => array(
            'Type' => 'text',
            'Size' => '7',
            'Default' => '0',
            'Description' => '',
        ),
        'Delete remaming credits at renew' => array(
            'Type' => 'yesno',
            'Default' => 'yes',
            'Description' => 'Tick to enable',
        ),
        'Load data from server for single product in Admin area' => array(
            'Type' => 'yesno',
            'Default' => 'yes',
            'Description' => 'Tick to enable',
        ),
        'Load data from server for single product in Client area' => array(
            'Type' => 'yesno',
            'Default' => 'yes',
            'Description' => 'Tick to enable',
        ),
/*
        'Avilable credits warninng' => array(
            'Type' => 'text',
            'Size' => '7',
            'Default' => '1000',
            'Description' => 'Warning email will be sent if you have less then this number available',
        ),
        'Avilable credits critical warninng' => array(
            'Type' => 'text',
            'Size' => '7',
            'Default' => '100',
            'Description' => 'Critical warning email will be sent if you have less then this number available',
        ),

        'Avilable subaccounts warninng' => array(
            'Type' => 'text',
            'Size' => '7',
            'Default' => '100',
            'Description' => 'Warning email will be sent if you have less then this number available',
        ),
        'Avilable subaccounts critical warninng' => array(
            'Type' => 'text',
            'Size' => '7',
            'Default' => '10',
            'Description' => 'Critical warning email will be sent if you have less then this number available',
        ),
*/        
    );
}

/**
 * Provision a new instance of a product/service.
 *
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_CreateAccount(array $params) {
    try {
        logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );

		// basic check 
		switch ($params['status']) {
			case 'Pending':
			case 'Active':
			case 'Completed':
				//ok
				break;
			case 'Suspended':
			case 'Cancelled':
			case 'Fraud':
				throw new Exception("Error: service is in status: ".$params['status'].".");
				break;
			case 'Terminated':
				throw new Exception("Error: service is in status: ".$params['status'].". 
					(If you change status to some other and try to run Create again it will not create service because server does not allow the creation of subaccount with email that was used before.)");
				break;			
			default:
				break;
		}

		// TODO
		$checkReseller = sibecp_checkReseller($params); 		
		
        // load service
        $service = Service::find($params['serviceid']); // Service is class based on tblhosting table
		if($service == null) { throw new Exception("Error: created service not found."); }        
		// check if there is available IP
		$foundip = sibecp_getNextIP($params['serveraccesshash'], $params['serverid']);
		if ($foundip === null) { throw new Exception('Unable to select IP. Check that server configuration have IP pools set properly.'); }
		// prepare email which will be used for Sendinblue account
		$SubaccountEmail = sibecp_getSibSubAccEmail($params['clientsdetails']['email'], $params['serviceid']);
		// Configure API key authorization: api-key
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
		$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
		// check if subaccount already exist 
		$foundChild = sibecp_getSubaccountFromSendinblueByServiceId($params);
		if ($foundChild === null) { // not exist => lets create account
			$data = new StdClass;
			$data->email = $SubaccountEmail;
			// sanitize data
			if (trim($params['clientsdetails']['firstname']) == '') 	{ $firstname 	= '(Not set)'; } else { $firstname = trim($params['clientsdetails']['firstname']); }
			if (trim($params['clientsdetails']['lastname']) == '') 		{ $lastname 	= '(Not set)'; } else { $lastname = trim($params['clientsdetails']['lastname']); }
			if (trim($params['clientsdetails']['companyname']) == '') 	{ $companyname 	= '(Not set)'; } else { $companyname = trim($params['clientsdetails']['companyname']); } 
			// password is automatically generated by whmcs
			if (trim($params['password']) == '') 						{ $password 	= '(NotSet)Dhf*R#mVfd9)'; } else { $password = trim($params['password']); }
			
			$data->firstName = $firstname;
			$data->lastName = $lastname;
			$data->companyName = $companyname;
			$data->password = $password;

			try { // we want to catch Sendinblue api specific errors
				$ResellerChild = $ResellerApiInstance->createResellerChild($data);
			} catch (SendinBlue\Client\ApiException $e) {
				throw new Exception ('Error: Error in creating subaccount: ' . $e->getMessage());
			}

			$childAuthKey = $ResellerChild->getAuthKey();
			// update data in service and custom fields
			$service->username = $SubaccountEmail;
			$service->created_at = date('Y-m-d H:i:s', time());
			$service->save();
			$updated_customfield_apikey = sibecp_setCustomFeildValue($params, FIELDNAME_APIKEY, $childAuthKey);
			// associate IP
			$ip = new \SendinBlue\Client\Model\ManageIp(array('ip' => $foundip)); // \SendinBlue\Client\Model\ManageIp | IP to dissociate
			$ResellerApiInstance->associateIpToChild($childAuthKey, $ip);
			// Add credits
			$addCreditsInt = (int) $params['configoption1'];
			$addCredits = new \SendinBlue\Client\Model\AddCredits(array('email' => $addCreditsInt)); // \SendinBlue\Client\Model\AddCredits | Values to post to add credit to a specific child account
		    $result = $ResellerApiInstance->addCredits($childAuthKey, $addCredits);
			// Finally enable SMTP
			$updateChildAccountStatus = new \SendinBlue\Client\Model\UpdateChildAccountStatus(array('transactionalEmail' => true)); // \SendinBlue\Client\Model\UpdateChildAccountStatus | values to update in child account status
		    $ResellerApiInstance->updateChildAccountStatus($childAuthKey, $updateChildAccountStatus);
		} else {
			throw new Exception('Error: subaccount already exist, unable to create subaccount');
		}
		
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}
/**
 * Renew an instance of a product/service.
 *
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_Renew(array $params) {
	try {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );

		// basic check 
		switch ($params['status']) {
			case 'Pending':
			case 'Active':
			case 'Completed':
				//ok
				break;
			case 'Suspended':
			case 'Cancelled':
			case 'Fraud':
			case 'Terminated':				
				throw new Exception("Error: service is in status: ".$params['status'].".");
				break;
			default:
				break;
		}
		
		$ChildInfo = sibecp_getSubaccount($params, true);
		$childAuthKey = $ChildInfo->getApiKeys()->getV3()[0]->getKey();

		//checks before update
		// generally we do not mind if everything is ok as we would like to take money anyway
		// and then if customer find out that there is problem it will be checked
		// therefore all checks here will be skipped
			/*   
			// sender domain must exist
			$ChildDomains = $ResellerApiInstance->getChildDomainsB($childAuthKey); 
			$foundDomainActive = false;
			foreach ($ChildDomains as $item) { if($item->active == '1') { $foundDomainActive = true; break; } }
			if ($foundDomainActive === false) { throw new Exception('Error: sender domain is not set at Sendinblue. Check service setup.'); }
			// assigned ips?
			$ChildIPs = $ChildInfo->getIps();
			if (count($ChildIPs) == 0) { throw new Exception('Error: Subaccount is not assigned to any IP. Check service setup.'); }		
			// SMTP enabled? suspended (disabled SMTP) account should not be renewed
			$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $childAuthKey);
			$AccountApiInstance = new SendinBlue\Client\Api\AccountApi(new GuzzleHttp641\Client(), $config);
			$SMTPenabled = $AccountApiInstance->getAccount()->getRelay()->getEnabled();
			if ($SMTPenabled === false) { throw new Exception('Error: subaccount SMTP is dissabled. Check service setup.'); }
			*/		 
		// proceed with renew		
		$EmailCredits = $ChildInfo->getCredits()->getEmailCredits();
		$addCreditsInt = (int) $params['configoption1'];
		// If option "Delete remaining credits" is on then add only the difference
		if ($params['configoption2'] == 'on') { $addCreditsInt = $addCreditsInt - $EmailCredits; }
		if ($addCreditsInt > 0) {
			$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
			$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
			$addCredits = new \SendinBlue\Client\Model\AddCredits(array('email' => $addCreditsInt)); // \SendinBlue\Client\Model\AddCredits | Values to post to add credit to a specific child account
		    $result = $ResellerApiInstance->addCredits($childAuthKey, $addCredits);
		}
		    
    } catch (Exception $e) { 
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }

    return 'success';
}
/**
 * Suspend an instance of a product/service.
 *
 * Suspension has two parts:
 * 1. disabling SMTP function which is used as suspension marker
 * 2. setting credists to 0 because beside SMTP is disabled client still can run campagin 
 * 
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_SuspendAccount(array $params) {
    try {
    	logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );

		// basic check 
		switch ($params['status']) {
			case 'Pending':
			case 'Active':
			case 'Completed':
				//ok
				break;
			case 'Suspended':
			case 'Cancelled':
			case 'Fraud':
			case 'Terminated':
				throw new Exception("Error: service is in status: ".$params['status'].".");
				break;
			default:
				break;
		}
		
		$childAuthKey = sibecp_getChildAuthKey($params);
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $childAuthKey);
		$AccountApiInstance = new SendinBlue\Client\Api\AccountApi(new GuzzleHttp641\Client(), $config);
		$SMTPenabled = $AccountApiInstance->getAccount()->getRelay()->getEnabled();
		if ($SMTPenabled === false) { $Suspended = 'Yes'; } else { $Suspended = 'No'; }
		
		if ($Suspended == 'Yes') {
			throw new Exception('Service is suspended on server.');
		} else {
			sibecp_updateSmtpStatus($params, false);
			// set credits to 0
			$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
			$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
			$ChildInfo = $ResellerApiInstance->getChildInfo($childAuthKey);
			$RemainingEmailCredits = $ChildInfo->getCredits()->getEmailCredits();
			$removeCredits = new \SendinBlue\Client\Model\RemoveCredits(array('email' => (int) $RemainingEmailCredits)); // \SendinBlue\Client\Model\RemoveCredits | Values to post to remove email or SMS credits from a specific child account
		    $result = $ResellerApiInstance->removeCredits($childAuthKey, $removeCredits);
			// store the number of credits before sunspension only if ->removeCredits is successful
			$updated_customfield = sibecp_setCustomFeildValue($params, FIELDNAME_CREDITS_ON_SUSPENSION, $RemainingEmailCredits);
		}		 
		
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}

/**
 * Un-suspend instance of a product/service.
 *
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_UnsuspendAccount(array $params) {
    try {
    	logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );
		
		// basic check 
		switch ($params['status']) {
			case 'Pending':
			case 'Active':
			case 'Completed':
			case 'Suspended':
				//ok
				break;
			case 'Cancelled':
			case 'Fraud':
			case 'Terminated':
				throw new Exception("Error: service is in status: ".$params['status'].".");
				break;
			default:
				break;
		}
		
		$childAuthKey = sibecp_getChildAuthKey($params);
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $childAuthKey);
		$AccountApiInstance = new SendinBlue\Client\Api\AccountApi(new GuzzleHttp641\Client(), $config);
		$SMTPenabled = $AccountApiInstance->getAccount()->getRelay()->getEnabled();
		if ($SMTPenabled === false) { $Suspended = 'Yes'; } else { $Suspended = 'No'; }
		
		if ($Suspended == 'No') {
			throw new Exception('Service is not suspendeed on server.');
		} else {
			sibecp_updateSmtpStatus($params, true);
			// restore credits
			$credits_to_restore = (int) sibecp_getCustomFeildValue($params, FIELDNAME_CREDITS_ON_SUSPENSION); // (int) should cover empty string
			if ($credits_to_restore > 0) {
				$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
				$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
				$addCredits = new \SendinBlue\Client\Model\AddCredits(array('email' => $credits_to_restore)); // \SendinBlue\Client\Model\AddCredits | Values to post to add credit to a specific child account
			    $result = $ResellerApiInstance->addCredits($childAuthKey, $addCredits);
			}
		}		
    	
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}

/**
 * Terminate instance of a product/service.
 *
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_TerminateAccount(array $params) {
    try {
    	logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );
		
		// basic check  
		switch ($params['status']) {
			case 'Pending':
			case 'Active':
			case 'Completed':
			case 'Suspended':
			case 'Cancelled':
			case 'Fraud':
				//ok
				break;
			case 'Terminated':
				throw new Exception("Error: service is in status: ".$params['status'].".");
				break;
			default:
				break;
		}
		
		$childAuthKey = sibecp_getChildAuthKey($params);
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
		$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
		$ResellerApiInstance->deleteResellerChild($childAuthKey);
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}

/**
 * Change the password for an instance of a product/service.
 *
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_ChangePassword(array $params) {
    try {
    	logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );
		
		throw new Exception("This product do not support password change.");
		
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}

/**
 * Upgrade or downgrade an instance of a product/service.
 *
 * Called to apply any change in product assignment or parameters. It is called to provision upgrade or downgrade orders, as well as being able to be invoked manually by an admin user.
 * This same function is called for upgrades and downgrades of both products and configurable options.
 *
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_ChangePackage(array $params)
{
    try {
    	logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );
		
		// basic check 
		switch ($params['status']) {
			case 'Pending':
			case 'Active':
			case 'Completed':
				// $params['sibmsg'] = 'test updating params from functions';
				throw new Exception("This command is not avilable in this version.");
				break;
			case 'Suspended':
			case 'Cancelled':
			case 'Fraud':
			case 'Terminated':
				throw new Exception("Error: service is in status: ".$params['status'].".");
				break;
			default:
				break;
		}
		
		throw new Exception("This command is not avilable in this version.");
		
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}

/**
 * Test connection with the given server parameters.
 *
 * @param array $params common module parameters
 * @return array
 */
function sibecp_TestConnection(array $params)
{
    try {
    	logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );
        
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
		$AccountApiInstance = new SendinBlue\Client\Api\AccountApi( new GuzzleHttp641\Client(), $config );
	    $result = $AccountApiInstance->getAccount();
        $success = true;
        $errorMsg = '';
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        $success = false;
        $errorMsg = $e->getMessage();
    }
    return array( 'success' => $success, 'error' => $errorMsg, );
}

/**
 * Additional actions an admin user can invoke.
 *
 * @return array
 */
function sibecp_AdminCustomButtonArray()
{
    return array(
        "Assign IP" => "buttonAssignIP",
        // "Entry IP Pool" => "buttonIpPoolEntry",
        // "Bad IP Pool" => "buttonIpPoolBad",
        // "Okay IP Pool" => "buttonIpPoolOkay",
        // "Good IP Pool" => "buttonIpPoolGood",
        // "Special IP Pool" => "buttonIpPoolSpecial",
    );
}
function sibecp_buttonAssignIP(array $params) {
    try {
    	$foundip = sibecp_getNextIP($params['serveraccesshash'], $params['serverid']);
		if ($foundip === null) { throw new Exception('Unable to select IP. Check that server configuration have IP pools set properly.'); }
		
		$childAuthKey = sibecp_getChildAuthKey($params);
		
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
		$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
		// this clean up will be skipped for now
			/* 
			// we do not want regulary to assign more then one IP to client so first clean up
			$ChildInfo = $ResellerApiInstance->getChildInfo($childAuthKey);
			$ChildIPs = $ChildInfo->getIps();
			foreach ($ChildIPs as $item) {
				$ip = new \SendinBlue\Client\Model\ManageIp(array('ip' => $item)); // \SendinBlue\Client\Model\ManageIp | IP to dissociate
				$ResellerApiInstance->dissociateIpFromChild($childAuthKey, $ip);	
			}
			*/
		// associate IP
		$ip = new \SendinBlue\Client\Model\ManageIp(array('ip' => $foundip)); // \SendinBlue\Client\Model\ManageIp | IP to dissociate
		$ResellerApiInstance->associateIpToChild($childAuthKey, $ip);
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}



function sibecp_buttonIpPoolEntry(array $params) {
    try {
		throw new Exception("This command is not avilable in this version.");
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}
function sibecp_buttonIpPoolBad(array $params) {
    try {
		throw new Exception("This command is not avilable in this version.");
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}
function sibecp_buttonIpPoolOkay(array $params) {
    try {
		throw new Exception("This command is not avilable in this version.");
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}
function sibecp_buttonIpPoolGood(array $params) {
    try {
		throw new Exception("This command is not avilable in this version.");
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}
function sibecp_buttonIpPoolSpecial(array $params) {
    try {
		throw new Exception("This command is not avilable in this version.");
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}




function sibecp_ClientAreaAllowedFunctions() {
	// used with: http://bs/whmcs/clientarea.php?action=sibecp_push ?
    return array(
        //'Push Domain' => 'push',
    );
}


/**
 * Additional actions a client user can invoke.
 *
 * @return array
 */
function sibecp_ClientAreaCustomButtonArray() {
    return array(
        //"Login to dashboard" => "loginToPlatformDahboard",
    );
}


/**
 * Custom function for performing an additional action.
 *
 * @param array $params common module parameters
 * @return string "success" or an error message
 */
function sibecp_customfunction(array $params)
{
    try {
    	// WHMCS will call ../clientarea.php?action=customfunction
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return $e->getMessage();
    }
    return 'success';
}

/**
 * Admin services tab additional fields.
 *
 * @param array $params common module parameters
 * @return array
 */
function sibecp_AdminServicesTabFields(array $params) {
	$data = array();
    try {
    	logModuleCall( MODULE_NAME, __FUNCTION__, $params, '', '' );
		
		// basic check 
		switch ($params['status']) {
			case 'Pending':
			case 'Active':
			case 'Completed':
			case 'Suspended':
			case 'Cancelled':
			case 'Fraud':
				// ok proceed
				break;
			case 'Terminated':
				return array();
				break;
			default:
				break;
		}
		
		if ($params['configoption3'] == 'on') { 
			// info will be loaded only if api-key is present localy in whmcs because of speed and this should be regular situation 
			$childAuthKey = sibecp_getCustomFeildValue($params, FIELDNAME_APIKEY);
			
			// account suspended?			
			$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $childAuthKey);
			$AccountApiInstance = new SendinBlue\Client\Api\AccountApi(new GuzzleHttp641\Client(), $config);
			$SMTPenabled = $AccountApiInstance->getAccount()->getRelay()->getEnabled();
			if ($SMTPenabled === false) { $Suspended = 'Yes'; } else { $Suspended = 'No'; }

			$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
			$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
			$ChildInfo = $ResellerApiInstance->getChildInfo($childAuthKey);

			// to find the pool for every assigned IP - could be moved to separate fn
			$AssignedIPsArray = array();
			$serverIPs = sibecp_getServerIPs($params['serverid']);
			$childIP = $ChildInfo->getIps();
			foreach ($childIP as $childItem) {
				$poolFound = '-/-';
				foreach ($serverIPs as $pool => $serverItem) {
					if (in_array($childItem, $serverItem)) {
						$poolFound = $pool;
					}
				}
				$AssignedIPsArray[] = $childItem . ' > ' . $poolFound . ' pool';
			}
			$AssignedIPs = implode(', ', $AssignedIPsArray);
			
			$data[' '] = '<strong>Sendinblue server data</strong>';
			$data['Registered Email'] = $ChildInfo->getEmail();
			$data['First name and Last name'] = $ChildInfo->getFirstName() . ' ' . $ChildInfo->getLastName();
			$data['Suspended'] = $Suspended;
			$ChildDomains = $ResellerApiInstance->getChildDomainsB($childAuthKey);
			foreach ($ChildDomains as $item) {
				if($item->active == '1') {
					$ChildDomainsActive[] = $item->domain; 
					$options .= '<option value="' . $item->domain .'">' . $item->domain . '</option>';
				}
			}
			$data['Sender domains'] = implode(', ', $ChildDomainsActive);
			$data['Assigned IPs'] = $AssignedIPs;
			$data['Remaining email credits'] = $ChildInfo->getCredits()->getEmailCredits();
			
			$data['Previous month total sent'] = $ChildInfo->getStatistics()->getPreviousMonthTotalSent();
			$data['Current month total sent'] = $ChildInfo->getStatistics()->getCurrentMonthTotalSent();
			$data['Total sent'] = $ChildInfo->getStatistics()->getTotalSent();

			// 2 columns could be made with following but then WHMCS confuse the order of rows  
			// $data['  '] = '<strong>Change data on Sendinblue server on save</strong>';
			// $data['Credists'] = '
				// <div class="fieldlabel" style="display:inline-block;">Add credists on save</div><div class="fieldarea" style="display:inline-block;"><input type="text" name="sibecp_adminAddCredits" value="" class="form-control" id="sibecp_adminAddCredits"></div>
				// <div style="display:inline-block;">&nbsp;&nbsp;&nbsp;</div>
				// <div class="fieldlabel" style="display:inline-block;">Remove credists on save</div><div class="fieldarea" style="display:inline-block;"><input type="text" name="sibecp_adminRemoveCredits" value="" size="25" class="form-control" id="sibecp_adminRemoveCredits"></div>
			// ';

			$data['Add credists on save'] = '<input type="text" name="sibecp_adminAddCredits" value="" class="form-control" style="width: 15%" />';
			$data['Remove credists on save'] = '<input type="text" name="sibecp_adminRemoveCredits" value="" class="form-control" style="width: 15%" />';
			$data['Add sender domain on save'] = '<input type="text" name="sibecp_adminAddSenderDomain" value="" class="form-control" style="width: 25%" />';
			$select = '<select name="sibecp_adminRemoveSenderDomain" class="form-control select-inline" id="sibecp_adminRemoveSenderDomain" class="form-control">';
			$select .= '<option value="0">- (Select sender domain) -</option>';
			$select .= $options; 
			$select .= '</select>';
			$data['Remove sender domain on save'] = $select;
			
			if (isset($params['sibmsg'])) { $data['Sendinblue message'] = $params['sibmsg']; }
		}
		
		
		
        return $data;
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        // In an error condition, simply return no additional fields to display.
    }
	if ( ($admin_msg = trim(sibecp_getCustomFeildValue($params, FIELDNAME_ADMIN_MESSAGES))) != '') { 
		$data['Admin messages'] = '<span style="color:#aa0000;">' . $admin_msg . '</span>';
	}
    return $data;
}

/**
 * Execute actions upon save of an instance of a product/service.
 *
 * @param array $params common module parameters
 */
function sibecp_AdminServicesTabFieldsSave(array $params) {
	// reset admin messages
	$updated_customfield = sibecp_setCustomFeildValue($params, FIELDNAME_ADMIN_MESSAGES, '');

	$childAuthKey = sibecp_getChildAuthKey($params);
	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
	$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );

    $addCreditsInt = (int) (isset($_REQUEST['sibecp_adminAddCredits']) ? $_REQUEST['sibecp_adminAddCredits'] : '');
	if ($addCreditsInt != 0) {
        try {
			$addCredits = new \SendinBlue\Client\Model\AddCredits(array('email' => $addCreditsInt)); // \SendinBlue\Client\Model\AddCredits | Values to post to add credit to a specific child account
		    $result = $ResellerApiInstance->addCredits($childAuthKey, $addCredits);
        } catch (Exception $e) {
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        }
	}
    $removeCreditsInt = (int) (isset($_REQUEST['sibecp_adminRemoveCredits']) ? $_REQUEST['sibecp_adminRemoveCredits'] : '');
	if ($removeCreditsInt != 0) {
        try {
			$removeCredits = new \SendinBlue\Client\Model\RemoveCredits(array('email' => $removeCreditsInt)); // \SendinBlue\Client\Model\RemoveCredits | Values to post to add credit to a specific child account
		    $result = $ResellerApiInstance->removeCredits($childAuthKey, $removeCredits);
        } catch (Exception $e) {
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        }
	}

    $AddSenderDomain = isset($_REQUEST['sibecp_adminAddSenderDomain']) ? trim($_REQUEST['sibecp_adminAddSenderDomain']) : '';
	if ($AddSenderDomain != '') {
        try {
        	$senderEmail = 'added_by_support@' . $AddSenderDomain;
			$result = sibecp_addSenderDomain($params, $senderEmail, true);
			// add it soendinblue
			$addChildDomain = new \SendinBlue\Client\Model\AddChildDomain(array('domain' => trim($AddSenderDomain))); // \SendinBlue\Client\Model\AddChildDomain | Sender domain to add for a specific child account	
		    $ResellerApiInstance->createChildDomain($childAuthKey, $addChildDomain);
        } catch (Exception $e) {
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        }
	}

    $RemoveSenderDomain = isset($_REQUEST['sibecp_adminRemoveSenderDomain']) ? trim($_REQUEST['sibecp_adminRemoveSenderDomain']) : '';
	if ($RemoveSenderDomain != '') {
        try {
        	$senderEmail = 'anything@' . $RemoveSenderDomain;
			sibecp_deleteSenderDomain($params, $senderEmail);
        } catch (Exception $e) {
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        }
	}

    // Look for a change in value to avoid making unnecessary service calls.
    // if ($originalFieldValue != $newFieldValue) {
        // try {
            // // Call the service's function, using the values provided by WHMCS
            // // in `$params`.
        // } catch (Exception $e) {
			// logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
            // // Otherwise, error conditions are not supported in this operation.
        // }
    // }
}

/**
 * Perform single sign-on for a given instance of a product/service.
 * When successful, returns a URL to which the user should be redirected.
 *
 * @param array $params common module parameters
 * @return array
 */
function sibecp_ServiceSingleSignOn(array $params) {
    try {
		$redirectUrl = sibecp_getClientDashboardUrl($params);
        return array( 'success' => true, 'redirectTo' => $redirectUrl );
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return array( 'success' => false, 'errorMsg' => $e->getMessage() );
    }
}

/**
 * Perform single sign-on for a server.
 * When successful, returns a URL to which the user should be redirected to.
 *
 * @param array $params common module parameters
 * @return array
 */
function sibecp_AdminSingleSignOn(array $params)
{
    try {
		// currentlu Seninblue API does not support SSO for admin accounts so here it is only plain link
		$redirectUrl = 'https://account.sendinblue.com/reseller';
		
        return array( 'success' => true, 'redirectTo' => $redirectUrl );
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        return array( 'success' => false, 'errorMsg' => $e->getMessage() );
    }
}

/**
 * Client area output logic handling.
 *
 * @param array $params common module parameters
 * @return array
 */
function sibecp_ClientArea(array $params) {
    // Determine the requested action and set service call parameters based on the action.
    $requestedAction = isset($_REQUEST['customAction']) ? $_REQUEST['customAction'] : '';
	$senderEmail = isset($_REQUEST['SenderEmail']) ? $_REQUEST['SenderEmail'] : '';

	switch ($requestedAction) {
		case 'manageSenderDomains':
	        $serviceAction = 'manageSenderDomains';
	        $templateFile = 'templates/managesenderemails.tpl';
			break;
		case 'deleteSenderDomain':
	        $serviceAction = 'deleteSenderDomain';
	        $templateFile = 'templates/managesenderemails.tpl';
			break;
		case 'resendEmail':
	        $serviceAction = 'resendEmail';
	        $templateFile = 'templates/managesenderemails.tpl';
			break;
		case 'addSenderDomain':
	        $serviceAction = 'addSenderDomain';
	        $templateFile = 'templates/managesenderemails.tpl';
			break;
		case 'manage': // not in use
	        $serviceAction = 'get_usage';
	        $templateFile = 'templates/manage.tpl';
			break;
		default:
	        $serviceAction = 'getStats';
	        $templateFile = 'templates/overview.tpl';
			break;
	}

	$dataTmpl = array();

    // Call the service's function based on the request action, using the values provided by WHMCS in `$params`.
	// action - has to go first as it changes the data displayed by template 
    try {
		$fn = 'sibecp_'.$serviceAction;
		$dataTmpl['result'] = $fn($params, $senderEmail);
    } catch (Exception $e) {
		logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() ); // Record the error in WHMCS's module log.
        // client should not see error details so him will be shown some generic error 
        // if error is repating admin should turn on logging in WHMCS and see in log about error details (and then turn off logging) 
        //$dataTmpl['errorMessage'] = $e->getMessage();
		$dataTmpl['errorMessage'] = CLIENT_ERROR_MSG_RETRY;
    }

	// template data		
	$data = sibecp_getClientSenderDomainsHTML($params);
	if(count($data['domains'])) {
		$dataTmpl['senderDomainsArr'] = $data['domains'];	
	} else {
		$dataTmpl['senderDomainsArr'] = array();
	} 
	$dataTmpl['senderEmailsError'] = $data['senderEmailsError'];
	switch ($templateFile) {
		case 'templates/overview.tpl':
			$dataTmpl['serverdata'] = false;  // do not want to be shown
			$dataTmpl['username'] = false;  // do not want to be shown
			$dataTmpl['showmanagedetails'] = false;
			$dataTmpl['redirectUrl'] = sibecp_getClientDashboardUrl($params);
			if ($params['configoption4'] == 'on') {
				$clientData = sibecp_getClientDataFromSendinblue($params);
				$dataTmpl['senderDomains'] = $clientData['Registered domains'];
				$dataTmpl['emailCredits'] = $clientData['Remaining email credits'];
				foreach ($clientData['Stats'] as $key => $value) {
					$a = array();
					$a['title'] = $key;
					$a['value'] = $value;
					$dataTmpl['stats'][] = $a;
				}
				
			}
			break;
		case 'templates/managesenderemails.tpl':
			if ($serviceAction != 'deleteSenderDomain') {
				$dataTmpl['submitedEmailAddress'] = $senderEmail;
			}
			break;
		default:
			break;
	}
	
    return array(
        'tabOverviewReplacementTemplate' => $templateFile,
        'templateVariables' => $dataTmpl
    );

}
function sibecp_manageSenderDomains(array $params, $senderEmail) {
	$result = null;
	return $result;
}
function sibecp_deleteSenderDomain(array $params, $senderEmail) {
	$emailArr = explode('@', $senderEmail);
	$senderDomain = $emailArr[1];
	
	// delete from sendinblue if it is added there (will not be added if it is not verified)
	$childAuthKey = sibecp_getCustomFeildValue($params, FIELDNAME_APIKEY);
	if ($childAuthKey == '') { return array('errorMessage' => 'Error in accessing to account.'); }
	
	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
	$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
	$ChildDomains = $ResellerApiInstance->getChildDomainsB($childAuthKey);
	foreach ($ChildDomains as $item) {
		if ($item->domain == $senderDomain) { $ResellerApiInstance->deleteChildDomain($childAuthKey, $item->domain); } 
	}
	
	$dataJSONraw = sibecp_getCustomFeildValue($params, FIELDNAME_SENDER_DOMAINS);
	$dataJSON = htmlspecialchars_decode($dataJSONraw);
	$dataOld = json_decode($dataJSON);
	$data = array();
	foreach ($dataOld as $item) { if($item->domain != $senderDomain) { $data[] = $item; } }
	
	$dataJSON = json_encode($data);

	if(!($update = sibecp_setCustomFeildValue($params, FIELDNAME_SENDER_DOMAINS, $dataJSON))) { return false; }
	
	$result['message'] = 'Deleted sender domain: ' . $senderDomain;
	return $result;
}
function sibecp_resendEmail(array $params, $senderEmail) {
	$dataJSONraw = sibecp_getCustomFeildValue($params, FIELDNAME_SENDER_DOMAINS);
	$dataJSON = htmlspecialchars_decode($dataJSONraw);	
	$dataOld = json_decode($dataJSON);

	$data = array();
	foreach ($dataOld as $item) {
		if($item->email == $senderEmail) {
			$item->submitted = date('Y-m-d H:i:s', time());
			$hash = sibecp_getRandomHash();  
			while (count(Capsule::table('tblcustomfieldsvalues')->where('value', 'like', '%' . $hash . '%')->get()) > 0) {
				$hash = sibecp_getRandomHash();
			}
			$item->hash = $hash;
			$item->verified = '';
		} 
		$data[] = $item;
	}
	
	$requestPos = strpos($_SERVER['REQUEST_URI'], 'clientarea.php');  
	$link = $_SERVER['HTTP_ORIGIN'] . substr($_SERVER['REQUEST_URI'], 0, $requestPos-1) . '/modules/servers/' . basename(__DIR__) . '/emailverify.php?vs='.urlencode($hash);	
	
	if (!($mailSent = sibecp_sendVerificationEmail($params, $senderEmail, $link))) { return false; }

	$dataJSON = json_encode($data);
	if(!($update = sibecp_setCustomFeildValue($params, FIELDNAME_SENDER_DOMAINS, $dataJSON))) { return false; }
	
	$result['message'] = 'The email with verification link is sent again to ' . $senderEmail;
	return $result;
}
function sibecp_addSenderDomain(array $params, $senderEmail, $admin = false) {
	if(!filter_var($senderEmail, FILTER_VALIDATE_EMAIL)) { throw new Exception('Invalid email address.'); }

	$emailArr = explode('@', $senderEmail);
	$senderDomain = $emailArr[1];
	
	$dataJSONraw = sibecp_getCustomFeildValue($params, FIELDNAME_SENDER_DOMAINS);
	$dataJSON = htmlspecialchars_decode($dataJSONraw);	
	$data = json_decode($dataJSON);

	if (count($data) > 31) { throw new Exception ('You can not have more than 32 sender domains.'); }
	
	foreach ($data as $item) { if($item->domain == $senderDomain) { throw new Exception ('Email with the same domain already exist. If you want to use differnt email address with the same domain first delete the old email address.'); } }

	if ($admin == false) {	
		$hash = sibecp_getRandomHash();  
		while (count(Capsule::table('tblcustomfieldsvalues')->where('value', 'like', '%' . $hash . '%')->get()) > 0) {
			$hash = sibecp_getRandomHash();
		}
		
		$requestPos = strpos($_SERVER['REQUEST_URI'], 'clientarea.php');  
		$link = $_SERVER['HTTP_ORIGIN'] . substr($_SERVER['REQUEST_URI'], 0, $requestPos-1) . '/modules/servers/' . basename(__DIR__) . '/emailverify.php?vs='.urlencode($hash);	
		
		if (!($mailSent = sibecp_sendVerificationEmail($params, $senderEmail, $link))) { return false; }
	}
		
	$item = new stdClass;
	$item->email = $senderEmail;
	$item->domain = $senderDomain;
	$item->submitted = date('Y-m-d H:i:s', time());
	if ($admin == false) {
		$item->verified = '';
		$item->hash = $hash;
	} else {
		$item->verified = $item->submitted;
		$item->hash = '';
	}
	$data[] = $item; 
	$dataJSON = json_encode($data);
	
	if(!($update = sibecp_setCustomFeildValue($params, FIELDNAME_SENDER_DOMAINS, $dataJSON))) { return false; }
	
	$result['message'] = 'The email with verification link is sent to ' . $senderEmail;
	return $result;
}
function sibecp_getStats(array $params) {
	// currently in main fn
	$result = null;
	return $result;
}

function sibecp_getClientDashboardUrl(array $params) {
	//this will be avilable only if api-key is present localy in whmcs because of speed and this should be regular situation
	$server = Capsule::table('tblservers')->where('id',$params['serverid'])->get();
	$hostname = $server[0]->hostname;
	$childAuthKey = sibecp_getCustomFeildValue($params, FIELDNAME_APIKEY);
	if ($childAuthKey != '') {
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
		$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
		try { // we want to catch Sendinblue api specific errors
			$SsoToken = $ResellerApiInstance->getSsoToken($childAuthKey)->getToken();
			$redirectUrl = 'https://' . $hostname . '/login/sso?token=' . $SsoToken;
		} catch (SendinBlue\Client\ApiException $e) {
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $e->getMessage(), $e->getTraceAsString() );
			switch ($e->getCode()) {
				case 401: //"Key not found"
					$redirectUrl = '#';
					break;
				default:
					// not found
					$redirectUrl = '#';
			}
		}
	} else {
		$redirectUrl = '#';
	}
	return $redirectUrl;
}
function sibecp_getClientDataFromSendinblue(array $params) {
	$data = array();
	//this will be avilable only if api-key is present localy in whmcs because of speed and this should be regular situation
	$childAuthKey = sibecp_getCustomFeildValue($params, FIELDNAME_APIKEY);
	if ($childAuthKey != '') {
		$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', $params['serveraccesshash']);
		$ResellerApiInstance	= new SendinBlue\Client\Api\ResellerApiB(new GuzzleHttp641\Client(), $config );
		$ChildInfo = $ResellerApiInstance->getChildInfo($childAuthKey);
		
		$ChildDomains = $ResellerApiInstance->getChildDomainsB($childAuthKey);
		foreach ($ChildDomains as $item) { if($item->active == '1') { $ChildDomainsActive[] = $item->domain; } }
		$data['Registered domains'] = implode(',', $ChildDomainsActive);
		
		$data['Assigned IPs'] = implode(',', $ChildInfo->getIps());
		$data['Remaining email credits'] = $ChildInfo->getCredits()->getEmailCredits();
		
		$data['Stats']['Previous month total sent'] = $ChildInfo->getStatistics()->getPreviousMonthTotalSent();
		$data['Stats']['Current month total sent'] = $ChildInfo->getStatistics()->getCurrentMonthTotalSent();
		$data['Stats']['Total sent'] = $ChildInfo->getStatistics()->getTotalSent();
	}
	return $data;
}

function sibecp_getClientSenderDomainsHTML(array $params) {
	$dataJSON = sibecp_getCustomFeildValue($params, FIELDNAME_SENDER_DOMAINS);
	$data = json_decode($dataJSON);
	
	$dataTmpl['senderEmailsError'] = true;
	foreach ($data as $item) {
		$arrItem = array();
		$arrItem['email'] = $item->email;
		$arrItem['domain'] = $item->domain;
		$arrItem['submitted'] = $item->submitted;
		if ($item->verified == '') {
			$arrItem['verified'] = '';
			$arrItem['verifiedtext'] = 'Not verified.';
			$arrItem['command_delete'] = true;
			$arrItem['command_resend'] = true; 
		} else {
			$arrItem['verified'] = $item->verified;
			$arrItem['verifiedtext'] = 'Verified: ' . $item->verified;
			$arrItem['command_delete'] = true;
			$dataTmpl['senderEmailsError'] = false;
		}
		$dataTmpl['domains'][] = $arrItem;
	}
	return $dataTmpl;
}

function sibecp_sendVerificationEmail(array $params, $senderEmail, $link) {
	$from = Setting::getValue('SystemEmailsFromEmail');
	$to = $senderEmail;
	$subject = 'Email verification';
	
	$message =  Setting::getValue('SystemEmailsFromEmail');
	$message .= '<p>Please click this link to activate your sender domain:</p><a href="' . $link . '">' . $link . '</a>';
	$message .= '<p></p><p>' . Setting::getValue('CompanyName') . '</a>';
		
	if(Setting::getValue('MailType') == 'smtp') {
		$sibecp_config = new sibecp_config;
		$mail = new PHPMailer;
		$mail->isSMTP();
		// $mail->SMTPDebug = SMTP::DEBUG_SERVER;
		// $mail->SMTPDebug = SMTP::DEBUG_CONNECTION;
		$mail->Host = Setting::getValue('SMTPHost');
		$mail->Port = Setting::getValue('SMTPPort');
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = Setting::getValue('SMTPSSL');
		$mail->Username = Setting::getValue('SMTPUsername');
		$mail->Password = $sibecp_config->SMTPpassword;
		
		$mail->setFrom($from, Setting::getValue('SystemEmailsFromName'));
		$mail->addAddress($to, '');
		$mail->Subject = $subject;
		$mail->isHTML(true);
		$mail->Body = $message;
		if (!$mail->send()) {
			// var_dump($mail->ErrorInfo);
			$logMsg = 'Error in sending SMTP email: '.$mail->ErrorInfo;
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $logMsg, '' );
			throw new Exception(CLIENT_ERROR_MSG_CONTACT_SUPPORT); 
		}		
	} else {
		$headers = 'From: ' . $from;
		if (!mail($to, $subject, $message, $headers)) {
			$logMsg = 'Error in sending PHP email.';
			logModuleCall( MODULE_NAME, __FUNCTION__, $params, $logMsg, '' );
			throw new Exception(CLIENT_ERROR_MSG_CONTACT_SUPPORT); 
		} 
	}
	return true;		
}	

function sibecp_getRandomHash( $AllowedChars = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890", $length = 128 ) { 
	$upperbound = strlen($AllowedChars);
	for ($ii = 1; $ii < ($length + 1); $ii++ ) {
	    $RandomHash .= substr($AllowedChars, (mt_rand(1, $upperbound) - 1), 1);
	}
	return $RandomHash;
}




/**
 * Check resller resources
 * 
 * @return   
 */
function sibecp_checkReseller(array $params) {
		//TODO check reseller - do reseler have enogh credist to assign to client
		// if there is not enough credits we can send email to address in server setup which could be entered in Username
		// ths should beadded in documentation
		
		// TODO chek reseller subaccounts remaing - 

				// reseler account ->plan
// 
               // [2] => SendinBlue\Client\Model\GetAccountPlan Object
                        // (
                            // [container:protected] => Array
                                // (
                                    // [type] => reseller
                                    // [creditsType] => sendLimit
                                    // [credits] => 9993
                                    // [startDate] => DateTime Object
                                        // (
                                            // [date] => 2019-10-26 00:00:00.000000
                                            // [timezone_type] => 3
                                            // [timezone] => UTC
                                        // )
// 
                                    // [endDate] => DateTime Object
                                        // (
                                            // [date] => 2019-12-31 00:00:00.000000
                                            // [timezone_type] => 3
                                            // [timezone] => UTC
                                        // )
// 
                                    // [userLimit] => 10
                                // )
// 
                        // )		
		// TODO this checks should be added to Hooks and cron
	return true;
}
