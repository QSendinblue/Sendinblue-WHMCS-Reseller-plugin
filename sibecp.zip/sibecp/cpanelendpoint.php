<?php
// load WHMCS
require_once '../../../init.php';
require_once 'sibecp.php';
use WHMCS\Database\Capsule;
use WHMCS\Config\Setting;

define('sFUNCTION', 'sibecp_cpanelendpoint');

$sibecp_config = new sibecp_config;

$token = $_REQUEST['access_token'];
$username = $_REQUEST['username'];
$ip = $_REQUEST['ip'];
//$hostname = $_REQUEST['hostname'];

$result = array(); $links = array();
$code = 200; $errorMsg = '';

if ($token != $sibecp_config->cpanelPluginAccessToken ) {
	$code = 401; 
	$errorMsg = 'Not authorized.'; 
} else {
	$rows = Capsule::table('tblservers')->where('ipaddress', $ip)->where('type', 'cpanel')->where('active', 1)->get();
	if (count($rows) != 1) {
		$errorMsg = 'Server not found.';
	} else {
		$serverid = $rows[0]->id;
		$rows = Capsule::table('tblhosting')->where('server', $serverid)->where('username', $username)->get();
		if (count($rows) == 0) { 
			$errorMsg = 'Hosting package not found.' . ' username: ' . $username . ', serverid: ' . $serverid;
		} else {
			$userid = $rows[0]->userid;
			// products - could be many 
			$rows = Capsule::table('tblproducts')->where('servertype', 'sibecp')->where('retired', 0)->get();
			if (count($rows) == 0) { 
				$errorMsg = 'Product not found.';
			} else {
				$products = array();
				foreach ($rows as $row) { $products[] = $row->id; }
				//$rows = Capsule::table('tblhosting')->whereIn('packageid', $products)->where('userid', $userid)->get();
				$rows = Capsule::table('tblhosting')->join('tblproducts', 'tblproducts.id', '=', 'tblhosting.packageid')->whereIn('packageid', $products)->where('userid', $userid)->get(['tblhosting.*', 'tblproducts.name']);
				// active only
				foreach ($rows as $row) {
					//$orders = Capsule::table('tblorders')->where('id', $row->orderid)->where('status', 'Active')->orWhere('status', 'Pending')->get();
					$orders = Capsule::table('tblorders')->where('id', $row->orderid)->where('status', 'Active')->get();
					if (count($orders) != 0) {
						$params = array(); 
						$server = Capsule::table('tblservers')->where('id', $row->server)->get();
						if (count($server) != 1) {
							$errorMsg = 'Server data not found.';
						} else {
							$params['serveraccesshash'] = $server[0]->accesshash; 
							$params['serviceid'] = $row->id;
							$params['serverid'] = $row->server;
							$params['packageid'] = $row->packageid;
							$row->dashboardUrl = sibecp_getClientDashboardUrl($params);
							$result[] = $row;
							$links[] = array('name' => $row->name, 'url' => $row->dashboardUrl, 'created_at' => $row->created_at);
						}
					}
				}
				// result has all active email packages for that user (in every cpanel of one user he will see all his email credists packages on one whmcs server)
				
				//echo var_dump($result);	
				//echo var_dump($links);	
			}
		}
	}
}
//echo json_encode(array('code' => $code, 'data' => $result, 'message' => $errorMsg));
echo json_encode(array('code' => $code, 'data' => $links, 'errorMessage' => $errorMsg));

