<?php

namespace GuzzleHttp641\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
