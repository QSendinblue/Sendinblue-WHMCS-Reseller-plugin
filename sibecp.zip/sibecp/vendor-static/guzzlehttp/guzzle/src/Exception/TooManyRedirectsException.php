<?php
namespace GuzzleHttp641\Exception;

class TooManyRedirectsException extends RequestException
{
}
