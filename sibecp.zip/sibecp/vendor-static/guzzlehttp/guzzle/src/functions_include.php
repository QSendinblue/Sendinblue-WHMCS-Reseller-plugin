<?php

// Don't redefine the functions if included multiple times.
if (!function_exists('GuzzleHttp641\uri_template')) {
    require __DIR__ . '/functions.php';
}
