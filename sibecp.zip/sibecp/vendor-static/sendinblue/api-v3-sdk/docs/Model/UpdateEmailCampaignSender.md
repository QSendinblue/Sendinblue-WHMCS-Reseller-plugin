# UpdateEmailCampaignSender

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Sender Name from which the campaign emails are sent | [optional] 
**email** | **string** | Sender email from which the campaign emails are sent | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


