# RemoveContactFromList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emails** | **string[]** | Required if &#39;all&#39; is false. Emails to remove from a list | [optional] 
**all** | **bool** | Required if &#39;emails&#39; is empty. Remove all existing contacts from a list | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


