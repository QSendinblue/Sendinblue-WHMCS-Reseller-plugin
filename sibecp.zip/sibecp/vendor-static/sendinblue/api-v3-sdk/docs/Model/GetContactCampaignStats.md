# GetContactCampaignStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messagesSent** | [**\SendinBlue\Client\Model\GetExtendedContactDetailsStatisticsMessagesSent[]**](GetExtendedContactDetailsStatisticsMessagesSent.md) |  | [optional] 
**hardBounces** | [**\SendinBlue\Client\Model\GetExtendedContactDetailsStatisticsMessagesSent[]**](GetExtendedContactDetailsStatisticsMessagesSent.md) |  | [optional] 
**softBounces** | [**\SendinBlue\Client\Model\GetExtendedContactDetailsStatisticsMessagesSent[]**](GetExtendedContactDetailsStatisticsMessagesSent.md) |  | [optional] 
**complaints** | [**\SendinBlue\Client\Model\GetExtendedContactDetailsStatisticsMessagesSent[]**](GetExtendedContactDetailsStatisticsMessagesSent.md) |  | [optional] 
**unsubscriptions** | [**\SendinBlue\Client\Model\GetContactCampaignStatsUnsubscriptions**](GetContactCampaignStatsUnsubscriptions.md) |  | [optional] 
**opened** | [**\SendinBlue\Client\Model\GetContactCampaignStatsOpened[]**](GetContactCampaignStatsOpened.md) |  | [optional] 
**clicked** | [**\SendinBlue\Client\Model\GetContactCampaignStatsClicked[]**](GetContactCampaignStatsClicked.md) |  | [optional] 
**transacAttributes** | [**\SendinBlue\Client\Model\GetContactCampaignStatsTransacAttributes[]**](GetContactCampaignStatsTransacAttributes.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


