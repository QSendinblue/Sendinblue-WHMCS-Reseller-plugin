# GetProcess

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Id of the process | 
**status** | **string** | Status of the process | 
**name** | **string** | Process name | 
**exportUrl** | **string** | URL on which send export the of contacts once the process is completed | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


