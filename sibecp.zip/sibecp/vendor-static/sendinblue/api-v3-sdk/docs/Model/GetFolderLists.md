# GetFolderLists

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lists** | **object[]** |  | 
**count** | **int** | Number of lists in the folder | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


