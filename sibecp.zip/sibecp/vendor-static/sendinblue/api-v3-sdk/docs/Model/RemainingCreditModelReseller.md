# RemainingCreditModelReseller

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sms** | **int** | SMS Credits remaining for reseller account | 
**email** | **int** | Email Credits remaining for reseller account | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


