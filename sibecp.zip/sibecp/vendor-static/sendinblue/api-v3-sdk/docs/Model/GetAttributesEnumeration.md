# GetAttributesEnumeration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **int** | ID of Value of the \&quot;category\&quot; type attribute | 
**label** | **string** | Label of the \&quot;category\&quot; type attribute | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


