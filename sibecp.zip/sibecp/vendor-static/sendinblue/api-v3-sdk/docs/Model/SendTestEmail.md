# SendTestEmail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emailTo** | **string[]** | List of the email addresses of the recipients whom you wish to send the test mail. If left empty, the test mail will be sent to your entire test list. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


