# GetFolders

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**folders** | **object[]** |  | [optional] 
**count** | **int** | Number of folders available in your account | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


