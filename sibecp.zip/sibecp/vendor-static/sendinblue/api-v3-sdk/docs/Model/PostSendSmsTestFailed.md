# PostSendSmsTestFailed

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **int** | Response code | 
**message** | **string** | Response message | 
**unexistingSms** | **string[]** |  | [optional] 
**withoutListSms** | **string[]** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


